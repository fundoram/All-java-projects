import java.util.Random;

public class Array {

	public static void main(String[] args) {
		// Declarations
		int sum = 0, count;
		double average;

		Random r = new Random();

		// Creating an Integer Array Of size 1000
		int arry[] = new int [1000];
		
		// Populating random numbers between 1-100 into an array

		for (int i = 0; i < 1000; i++) {
			// Generating the random number between 1-100
			arry[i] = r.nextInt(100) + 1;
			// calculating the sum
			sum += arry[i];
	
		}
		System.out.println("NEW ARRAY");
		for (int k=0; k<arry.length; k++) {
			System.out.println(arry[k]+" ");
		}

		// calculating the average
		average = (double) sum / 1000;

		// Displaying the average
		System.out.printf("Average :%.2f\n\n", average);

		// This Nested for loop will count no of occurrences of each number in the array
		for (int i = 1; i <= 100; i++) {
			int temp = i;
			count = 0;

			for (int j = 0; j < arry.length; j++) {
				if (temp == arry[j]) {
					count++;
				}
			}

			// Displaying the result
			System.out.println(i + " appears " + count + " times");
		}
	}

}