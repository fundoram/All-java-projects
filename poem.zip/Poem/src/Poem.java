import java.util.Scanner;

public class Poem {

    private static int getValidMinIndex(int index1, int index2, int index3) {
        int minIndex = -1;

        if (index1 >= 0) {
            minIndex = index1;
        }

        if (index2 >= 0) {
            minIndex = (minIndex == -1) ? index2 : Math.min(index1, index2);
        }

        if (index3 >= 0) {
            minIndex = (minIndex == -1) ? index3 : Math.min(minIndex, index3);
        }

        return minIndex;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String myName;
        do {
            System.out.println("Please enter your name:");// did this to receive user input and needed to replace witg name
            myName = scanner.nextLine();// gets the user input
        } while (myName.trim().length() <= 0);

        System.out.println("Please enter a line of text:");
        String text = scanner.nextLine();
        scanner.close();
        if (text != null) {
            String STR1 = "It";
            String STR2 = "it";
            String STR3 = ",";

            int index1 = text.indexOf(STR1);
            int index2 = text.indexOf(STR2);
            int index3 = text.indexOf(STR3);

            int minIndex = getValidMinIndex(index1, index2, index3);
            int fromIndex = 0;

            StringBuilder textBuilder = new StringBuilder("");

            while (minIndex >= 0) {

                textBuilder.append(text, fromIndex, minIndex);

                if (minIndex == index1) {

                    textBuilder.append(myName); // Replace "It" with name

                    fromIndex = index1 + STR1.length() - 1;
                    index1 = text.indexOf(STR1, fromIndex);


                } else if (minIndex == index2) {

                    textBuilder.append(" ");
                    textBuilder.append(myName); // Replace "it" with name

                    fromIndex = index2 + STR2.length() - 1;
                    index2 = text.indexOf(STR2, fromIndex);

                } else {

                    textBuilder.append(":"); // Replace "," with ":"

                    fromIndex = index3 + STR3.length();
                    index3 = text.indexOf(STR3, fromIndex);

                }

                minIndex = getValidMinIndex(index1, index2, index3);
            }

            textBuilder.append(text, fromIndex, text.length());

            System.out.println("Resulting string: ");
            System.out.println(textBuilder.toString());
        }
    }
}
