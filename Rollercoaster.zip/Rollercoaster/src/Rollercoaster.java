import java.util.Scanner; // necessary to get user input
public class Rollercoaster {

	public static void main(String[] arg) {
 boolean ageweight=true;// used boolean as a basic check to make sure user inputs valid info
	while(ageweight) {	
Scanner reader=new Scanner(System.in);// created to get the user input

  System.out.println("how old are you");
   int age=0;// set age at a constant 0 
  int weight=0;// same as what int age

  try {
	age=reader.nextInt();
	System.out.println("How much do you weight");
weight=reader.nextInt();
	if (age>0 && weight>0) {
		
		ageweight=false;// same as the boolean at first point 
		getRollercoaster(age, weight);
		reader.close();// closes scanner
	}
	}catch (Exception e) {
		
	}
	}
	}
	public static void getRollercoaster(int age, int weight) {// set up in order to create getrollercoaste
		//basic if else statements that print out the necessary outputs computed y what the user enters
		if (age<10 && weight<80) {
			System.out.println("This person needs to ride the black roller coaster.");
		}else if(age<10 && weight>=80 &&weight<=200) {
			System.out.println("This person needs to ride the green roller coaster.");
		}else if(age<=10 && weight>200) {
			System.out.println("This person needs to ride the yellow roller coaster.");
		}else if(age<=20 && age>10 && weight<80) {
		System.out.println("This person needs to ride the silver roller coaster");
		}else if(age<=20 && age>10 && weight>=80 && weight<=200) {
			System.out.println("This person needs to ride the red roller coaster");
		}else if(age<=20 && age>10 && weight>200) {
		System.out.println("This person needs to ride the purple coaster");
	
		}else
			System.out.println("This person needs to ride the pink coaster");

	
	}
}

	

