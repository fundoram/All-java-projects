import java.util.Scanner;// imports scanner to get user input

public class Cities {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);//created for user input

		System.out.println("Enter the city names");//prints to user
		String line = reader.nextLine();//gets the user input
		reader.close();//closes the reader
		String[] cities = line.split("\\s");
		String str1 = cities[0];
		String str2 = cities[1];
		String str3 = cities[2];
	
		//comparison 
		if (str1.compareTo(str2) < 0) {
			if (str1.compareTo(str3) >= 0) {
				System.out.println(str3 + " " + str1 + " " + str2);
			} else if (str1.compareTo(str3) < 0 && str2.compareTo(str3) >= 0) {
				System.out.println(str1 + " " + str3 + " " + str2);
			} else {
				System.out.println(str1 + " " + str2 + " " + str3);
			}
		} else if (str1.compareTo(str2) > 0) {
			if (str2.compareTo(str3) >= 0) {
				System.out.println(str3 + " " + str2 + " " + str1);
			} else if (str2.compareTo(str3) < 0 && str1.compareTo(str3) >= 0) {
				System.out.println(str2 + " " + str3 + " " + str1);
			} else {
				System.out.println(str2 + " " + str1 + " " + str3);
			}
		} else {
			if (str1.compareTo(str3) >= 0) {
				System.out.println(str3 + " " + str1 + " " + str2);
			} else {
				System.out.println(str1 + " " + str2 + " " + str3);
			}
		}
	}

}
