package classesAndObjects;

import static java.lang.Math.sqrt;


public class Rectangle{
	

   private double width;
   private double height;
   
   public Rectangle() 
      {
         width = 1;
         height = 1;
      }
   public Rectangle(double wid, double hei)
      {
         width = wid;
         height = hei;
      }
   public double getArea()
      {
         return width * height;
      }
   public double getPerimeter()
      {
         return (width + width + height + height);
      }
   public double getWidth()
      {
         return width;
      }
   public double getHeight()
      {
         return height;
      }
   public double getDiagonal()
      {
         return sqrt((height * height) + (width * width));
      }

}
