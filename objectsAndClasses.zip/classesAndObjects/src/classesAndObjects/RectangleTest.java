package classesAndObjects;

import java.util.Scanner;
import java.text.DecimalFormat;

public class RectangleTest{

   public static void main(String[] args){
   
   
         int userChoice = 0;
         
         Rectangle rec1 = new Rectangle(4,40);
         Rectangle rec2 = new Rectangle(3.5,35.9);
         
         Scanner input = new Scanner(System.in);
         DecimalFormat f = new DecimalFormat("##.00");
         
            do{
                  System.out.println("Welcome to the rectangle Class program");
                  System.out.println("1. To start the program");
                  System.out.println("2. To quit the program");
                  userChoice = input.nextInt();
                 
                  switch(userChoice)
                     {     
                        case 1:
                     
                           System.out.println("The width of the first recatngle is " + rec1.getWidth());
                           System.out.println("\nThe width of the second rectangle is " + rec2.getWidth());
                     
                           System.out.println("\nThe height of the first rectangle is " + rec1.getHeight());
                           System.out.println("\nThe height of the second rectangle is " + rec2.getHeight());
                     
                           System.out.println("\nThe area of the first rectangle is " + f.format(rec1.getArea()));
                           System.out.println("\nThe area of the second rectangle is " + f.format(rec2.getArea()));
                     
                           
                           System.out.println("\nThe perimeter of the first rectangle is " + rec1.getPerimeter());
                           System.out.println("\nThe perimeter of the second rectangle is " + rec2.getPerimeter());
                    
                           System.out.println("\nThe diagonal of the first rectangle is " + f.format(rec1.getDiagonal()));
                           System.out.println("\nThe diagonal of the second rectangle is " + f.format(rec2.getDiagonal())+ "\n");
                     
                           break;
                  
                        case 2:
                  
                           System.out.println("Bye friend");
                           System.exit(0);
                           input.close();
                           
                        default:
                  
                           System.out.println("1 or 2 integer values only please");
                     
                        break;
               
                     }
   
   
            }while(userChoice != 2);
   
         }

}
